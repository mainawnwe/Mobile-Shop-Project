<?php
session_start();
include('connection.php'); // Ensure this file contains your PDO connection code

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo '<div class="alert alert-danger" role="alert">Order ID is missing.</div>';
    exit;
}

$orderId = (int)$_GET['id'];

try {
    $stmt = $connection->prepare("DELETE FROM `order` WHERE id = ?");
    $stmt->execute([$orderId]);

    header('Location: index.php');
    exit;
} catch (PDOException $e) {
    echo '<div class="alert alert-danger" role="alert">Database error: ' . htmlspecialchars($e->getMessage()) . '</div>';
    exit;
}
?>
