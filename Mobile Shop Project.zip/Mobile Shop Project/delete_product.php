<?php
include('connection.php');

if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // Fetch the product's image path
    $stmt = $connection->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        // Delete the product from the database
        $stmt = $connection->prepare("DELETE FROM products WHERE id = ?");
        if ($stmt->execute([$product_id])) {
            // Optionally delete the product's image file
            if (file_exists($product['image'])) {
                unlink($product['image']);
            }
            header('Location: admin.php');
            exit;
        } else {
            echo "Failed to delete product.";
        }
    } else {
        echo "Product not found!";
    }
} else {
    echo "Invalid product ID!";
}
?>
