<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('connection.php'); // Include your PDO connection script
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    try {
        $sql = "DELETE FROM contact WHERE id = :id";
        $stmt = $connection->prepare($sql);
        $stmt->bindParam(':id', $id);
        if ($stmt->execute()) {
            $success = "Contact deleted successfully!";
        } else {
            $error = "Error: Could not delete contact.";
        }
    } catch (PDOException $e) {
        $error = 'Error: ' . $e->getMessage();
    }
}

// Fetch contacts from the database
try {
    $sql = "SELECT * FROM contact";
    $stmt = $connection->prepare($sql);
    $stmt->execute();
    $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = 'Error: ' . $e->getMessage();
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contacts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<body>


    <div class="container admin-functions" id="container" >

        <div class="container mt-12">
            <div class="row">
                <center>
                    <div class="col-lg-4">

                        <h2 class="text-center bg-light text-danger" style=" border-radius: 5px; padding: 4px ;">
                            <img src="image/contact_list_icon.png" width="12%" height="12%" alt="">
                            Manage Contacts
                        </h2>
                    </div>
                </center>
            </div>

        </div>
        <h1>Contacts List</h1>
        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Message</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($contacts as $contact): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($contact['id']); ?></td>
                        <td><?php echo htmlspecialchars($contact['name']); ?></td>
                        <td><?php echo htmlspecialchars($contact['email']); ?></td>
                        <td><?php echo htmlspecialchars($contact['phone']); ?></td>
                        <td><?php echo htmlspecialchars($contact['address']); ?></td>
                        <td><?php echo htmlspecialchars($contact['message']); ?></td>
                        <td>
                            <a href="edit_contact.php?id=<?php echo $contact['id']; ?>" class="btn btn-warning btn-sm">Edit</a><br><br>
                            <a href="?delete=<?php echo $contact['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this contact?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-d7K1F2L5H3Zt5i8b7Uu45xIj4ZBQ2w0PR2wFi1biBLx7V7G7t6Yr3F5zQsoRiFhP" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cHf0FsW+dy7I7F4gV3b+FpfbH1uYhHEKmyL6UBdD8U1OQ8Pz0E4+EB1o9V2eP0AY" crossorigin="anonymous"></script>
</body>

</html>