-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 12, 2024 at 02:39 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `name`, `product_name`, `total_price`, `phone`, `address`, `created_at`, `quantity`) VALUES
(17, 'Ko Naing Kyaw', 'iphone12', 1200.00, '09456459778', 'Yangon, Myaynigone, Sanchaung', '2024-08-11 02:43:58', 0),
(1, 'Win Xtun Zaw', 'iphone12, oneplus9', 1788.00, '09687004417', 'Myanmar, Yangon, Sanchaung, Myaynigone', '2024-08-10 04:17:21', 0),
(2, 'Ko Naing Kyaw', 'Samsung 21, pixel5', 1800.00, '09456459778', 'Yangon, Myaynigone, Sanchaung', '2024-08-10 05:13:58', 0),
(18, 'Ko Naing Kyaw', 'Oppo Find X6 Pro', 1089.00, '09456459778', 'Yangon, Myaynigone, Sanchaung', '2024-08-11 05:26:39', 0),
(19, 'Ko Naing Kyaw', 'Oppo Find X7 Ultra, Oppo Find X6 Pro, Oppo Find N2 Flip', 3470.00, '09456459778', 'Yangon, Myaynigone, Sanchaung', '2024-08-12 03:39:32', 3),
(20, 'Ko Naing Kyaw', 'Xiaomi Mi 11 Ultra, Oppo Find X3 Pro, OnePlus 9, OnePlus 9 Pro', 4046.00, '09456459778', 'Yangon, Myaynigone, Sanchaung', '2024-08-12 03:42:52', 4),
(21, 'Ko Naing Kyaw', 'Xiaomi Mi 11 Ultra, Oppo Find X3 Pro, OnePlus 9, OnePlus 9 Pro', 4046.00, '09456459778', 'Yangon, Myaynigone, Sanchaung', '2024-08-12 03:43:50', 4),
(22, 'Ko Naing Kyaw', 'Vivo V21e, Vivo Y33s', 528.00, '09456459778', 'Yangon, Myaynigone, Sanchaung', '2024-08-12 07:07:30', 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
