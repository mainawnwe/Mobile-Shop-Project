-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 12, 2024 at 02:39 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `price` int DEFAULT NULL,
  `image` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`, `type`) VALUES
(60, 'Oppo Find X7 Ultra', 1222, 'images/Oppo-FInd-X7-Ultra.jpg', 'oppo'),
(59, 'Oppo Find X6 Pro', 1089, 'images/Oppo-Find-X6-Pro-Green.jpg', 'oppo'),
(58, 'Oppo Find N2 Flip', 1159, 'images/Oppo_find_n2_flip.jpg', 'oppo'),
(54, 'Xiaomi Mi 11 Ultra', 1199, 'images/mi-11-ultra.png', 'Xiaomi'),
(55, 'Xiaomi Mi 11', 749, 'images/mi-11.png', 'Xiaomi'),
(57, 'Oppo Find X3 Pro', 1149, 'images/oppo-find-x3-pro.jpg', 'oppo'),
(49, 'OnePlus 9', 729, 'images/one-plus-9.png', 'oneplus'),
(48, 'OnePlus 9 Pro', 969, 'images/one-plus-9-pro.png', 'oneplus'),
(47, 'Google Pixel 6', 599, 'images/googlepixel6.jpg', 'google_pixel'),
(46, 'Google Pixel 6 Pro', 899, 'images/Google-Pixel-6-Pro.png', 'google_pixel'),
(45, 'Samsung Galaxy S21 5G', 799, 'images/Galaxy-S21-5G-Pink.webp', 'samsung'),
(44, 'Samsung Galaxy S21 Ultra', 1199, 'images/galaxy-s21-ultra-5g.avif', 'samsung'),
(43, 'iPhone 16 Pro Max', 1440, 'images/iPhone-16-Pro-Max.webp', 'iphone'),
(42, 'iPhone 15 Pro Max', 1199, 'images/iPhone_15_Pro_Max.jpg', 'iphone'),
(40, 'iPhone 13 Pro Max', 1099, 'images/Apple-iPhone-13-Pro-Max_2.jpg', 'iphone'),
(41, 'iPhone 14 Plus', 1099, 'images/iphone14plus.jpg', 'iphone'),
(39, 'iphone12', 307, 'images/iphone12.webp', 'iphone'),
(61, 'Vivo X80 Pro', 1199, 'images/Vivo-X80-Pro.png', 'vivo'),
(62, 'Vivo X60 Pro+', 799, 'images/Vivo-X60-Pro+.png', 'vivo'),
(63, 'Vivo X60 Pro', 788, 'images/Vivo-X60-Pro.png', 'vivo'),
(64, 'Vivo X70 Pro+', 899, 'images/Vivo-X70-Pro+.png', 'vivo'),
(65, 'Vivo Y76 5G', 309, 'images/Vivo-Y76-5G.png', 'vivo'),
(66, 'Vivo V23 5G', 399, 'images/Vivo-V23-5G.png', 'vivo'),
(67, 'Vivo Y33s', 249, 'images/Vivo-Y33s.png', 'vivo'),
(68, 'Vivo V21e', 279, 'images/Vivo-V21e.jpg', 'vivo');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
