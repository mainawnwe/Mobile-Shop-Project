-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 12, 2024 at 02:39 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(33, 15, 8, 1, 600.00),
(32, 15, 5, 200, 1200.00),
(31, 14, 7, 1, 588.00),
(30, 14, 6, 1, 1200.00),
(29, 13, 7, 1, 588.00),
(28, 13, 6, 1, 1200.00),
(27, 12, 7, 1, 588.00),
(26, 12, 6, 1, 1200.00),
(25, 11, 7, 1, 588.00),
(24, 11, 6, 1, 1200.00),
(23, 10, 7, 1, 588.00),
(22, 10, 6, 1, 1200.00),
(21, 9, 7, 1, 588.00),
(20, 9, 6, 1, 1200.00),
(19, 8, 7, 1, 588.00),
(18, 8, 6, 1, 1200.00),
(35, 16, 8, 1, 600.00),
(36, 17, 6, 1, 1200.00),
(37, 18, 59, 1, 1089.00),
(38, 19, 60, 1, 1222.00),
(39, 19, 59, 1, 1089.00),
(40, 19, 58, 1, 1159.00),
(41, 20, 54, 1, 1199.00),
(42, 20, 57, 1, 1149.00),
(43, 20, 49, 1, 729.00),
(44, 20, 48, 1, 969.00),
(45, 21, 54, 1, 1199.00),
(46, 21, 57, 1, 1149.00),
(47, 21, 49, 1, 729.00),
(48, 21, 48, 1, 969.00),
(49, 22, 68, 1, 279.00),
(50, 22, 67, 1, 249.00);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
