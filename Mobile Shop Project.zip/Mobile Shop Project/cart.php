<?php
session_start();
include('connection.php');

// Fetch products from the database
$stmt = $connection->query("SELECT * FROM products");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .cart-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .cart-header {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
        }

        .cart-header h1 {
            color: brown;
            margin: 0;
        }

        .cart-table {
            margin-top: 20px;
            width: 100%;
        }

        .cart-table img {
            max-height: 100px;
            width: auto;
        }

        .cart-table th,
        .cart-table td {
            text-align: center;
            vertical-align: middle;
        }

        .cart-table th {
            background-color: #e9ecef;
            color: #343a40;
        }

        .total-section {
            font-size: 1.5rem;
            font-weight: bold;
            margin-top: 20px;
            text-align: right;
        }

        .order-button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px 24px;
            font-size: 1.25rem;
            border-radius: 5px;
            display: block;
            margin-left: auto;
            margin-top: 20px;
        }

        .order-button:hover {
            background-color: #218838;
        }

        .empty-cart {
            text-align: center;
            padding: 50px;
            font-size: 1.25rem;
            color: #6c757d;
        }
    </style>
</head>

<body>
    <header>
        <!-- Header Start -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="image/mainawlogo.png" alt="My Mobile Shop" width="70" height="70" class="d-inline-block align-text-top rounded-circle">
                </a>
                <h3>Mai Naw Mobile</h3>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active btn btn-primary text-white" href="index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-fill" viewBox="0 0 16 16">
                                    <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293z" />
                                    <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293z" />
                                </svg>
                                Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-info text-white" href="products.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-fill" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M15.528 2.973a.75.75 0 0 1 .472.696v8.662a.75.75 0 0 1-.472.696l-7.25 2.9a.75.75 0 0 1-.557 0l-7.25-2.9A.75.75 0 0 1 0 12.331V3.669a.75.75 0 0 1 .471-.696L7.443.184l.004-.001.274-.11a.75.75 0 0 1 .558 0l.274.11.004.001zm-1.374.527L8 5.962 1.846 3.5 1 3.839v.4l6.5 2.6v7.922l.5.2.5-.2V6.84l6.5-2.6v-.4l-.846-.339Z" />
                                </svg>
                                Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-success text-white" href="login.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bag-plus-fill" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z" />
                                </svg>
                                Admin
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link btn btn-secondary text-white" href="contact.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                                </svg>
                                Contact
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-warning text-white" href="cart.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-cart-check-fill" viewBox="0 0 16 16">
                                    <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m-1.646-7.646-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L8 8.293l2.646-2.647a.5.5 0 0 1 .708.708" />
                                </svg>
                                Cart <span class="badge bg-danger"><?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : '0'; ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Header End -->
    </header>

    <div class="cart-container">
        <div class="cart-header">
            <h1>Shopping Cart</h1>
        </div>

        <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
            <?php
            $total = 0;
            ?>
            <table class="table table-bordered cart-table">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($_SESSION['cart'] as $productId => $quantity): ?>
                        <?php
                        // Find the product
                        $product = array_filter($products, function ($p) use ($productId) {
                            return $p['id'] == $productId;
                        });
                        $product = array_shift($product);

                        if ($product):
                            $subtotal = $product['price'] * $quantity;
                            $total += $subtotal;
                        ?>
                            <tr>
                                <td><img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>"></td>
                                <td><?php echo htmlspecialchars($product['name']); ?></td>
                                <td>$<?php echo htmlspecialchars($product['price']); ?></td>
                                <td><?php echo htmlspecialchars($quantity); ?></td>
                                <td>$<?php echo htmlspecialchars($subtotal); ?></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>

            </table>

            <div class="total-section">
                Total: $<?php echo htmlspecialchars($total); ?>
            </div>

            <form action="order.php" method="post">
                <input type="hidden" name="total" value="<?php echo htmlspecialchars($total); ?>">
                <button type="submit" class="order-button">Order Now</button>
            </form>
        <?php else: ?>
            <div class="empty-cart">Your cart is empty.</div>
        <?php endif; ?>
    </div>
    <footer class="bg-light text-center text-lg-start">
            <div class="container p-4">
                <div class="row">
                    <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
                        <h5 class="text-uppercase" style="color:#d14617;">My Mobile Shop</h5>
                        <p>Your one-stop shop for the latest mobile phones. We offer a wide range of smartphones with the best deals and discounts.</p>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                        <h5 class="text-uppercase" style="color:#d14617;">Quick Links</h5>
                        <ul class="list-unstyled mb-0">
                            <li><a href="index.php" class="text-dark">Home</a></li>
                            <li><a href="products.php" class="text-dark">Products</a></li>
                            <li><a href="cart.php" class="text-dark">Cart</a></li>
                            <li><a href="contact.php" class="text-dark">Contact</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                        <h5 class="text-uppercase" style="color:#d14617;">Contact Us</h5>
                        <ul class="list-unstyled mb-0">
                            <li><i class="bi bi-geo-alt"></i> Myaynigone, Yangon</li>
                            <li><i class="bi bi-envelope"></i> mycontact.com101@gmail.com</li>
                            <li><i class="bi bi-phone"></i> +95 9 456 459 778</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="text-center p-3 bg-dark text-white">
                &copy; 2024 Mai Naw Mobile. All rights reserved.
            </div>
        </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>