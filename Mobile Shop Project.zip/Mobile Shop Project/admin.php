<?php
// Start the session only if it hasn't already been started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('connection.php');

// Handle form submission for adding a product
if (isset($_POST['submit'])) {
    $name = trim($_POST['name']);
    $price = trim($_POST['price']);
    $type = trim($_POST['type']);

    // Basic validation
    if (empty($name) || empty($price) || empty($type)) {
        $error = 'Please fill in all fields.';
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = 'Please enter a valid price.';
    } else {
        // Handle file upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
            $image = $_FILES['image'];
            $imageName = basename($image['name']);
            $imagePath = 'images/' . $imageName;

            if (move_uploaded_file($image['tmp_name'], $imagePath)) {
                // Insert product into database
                $stmt = $connection->prepare("INSERT INTO products (name, price, type, image) VALUES (?, ?, ?, ?)");
                if ($stmt->execute([$name, $price, $type, $imagePath])) {
                    $success = 'Product added successfully!';
                } else {
                    $error = 'Failed to add product. Please try again.';
                }
            } else {
                $error = 'Failed to upload image.';
            }
        } else {
            $error = 'No image uploaded or an error occurred.';
        }
    }
}

// Fetch products for display
$products = $connection->query("SELECT * FROM products")->fetchAll(PDO::FETCH_ASSOC);

// Fetch orders for display
$order = $connection->query("SELECT * FROM `order`")->fetchAll(PDO::FETCH_ASSOC);

// Fetch order items for display
$orderItems = $connection->query("SELECT * FROM order_items")->fetchAll(PDO::FETCH_ASSOC);

// Fetch users for display
$users = $connection->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            padding: 20px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .admin-functions {
            padding: 20px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header-logo {
            width: 70px;
            height: 70px;
            border-radius: 50%;
        }

        .table {
            margin-top: 20px;
        }

        .table th,
        .table td {
            text-align: center;
        }
    </style>
    <script>
        function confirmDelete(url) {
            if (confirm("Are you sure you want to delete this product?")) {
                window.location.href = url;
            }
        }
    </script>
</head>

<body>
    <header>
        <!-- Header Start -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="image/mainawlogo.png" alt="My Mobile Shop" class="header-logo">
                </a>
                <h3 class="header-title">Mai Naw Mobile</h3>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active btn btn-primary text-white" href="index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-fill" viewBox="0 0 16 16">
                                    <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293z" />
                                    <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293z" />
                                </svg>
                                Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-info text-dark" href="products.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-fill" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M15.528 2.973a.75.75 0 0 1 .472.696v8.662a.75.75 0 0 1-.472.696l-7.25 2.9a.75.75 0 0 1-.557 0l-7.25-2.9A.75.75 0 0 1 0 12.331V3.669a.75.75 0 0 1 .471-.696L7.443.184l.004-.001.274-.11a.75.75 0 0 1 .558 0l.274.11.004.001zm-1.374.527L8 5.962 1.846 3.5 1 3.839v.4l6.5 2.6v7.922l.5.2.5-.2V6.84l6.5-2.6v-.4l-.846-.339Z" />
                                </svg>
                                Products
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link btn btn-success text-white" href="login.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bag-plus-fill" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z" />
                                </svg>
                                Admin
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-secondary text-white" href="contact.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                                </svg>
                                Contact
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-warning text-dark" href="cart.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-check-fill" viewBox="0 0 16 16">
                                    <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m-1.646-7.646-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L8 8.293l2.646-2.647a.5.5 0 0 1 .708.708" />
                                </svg>
                                Cart <span class="badge bg-danger"><?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : '0'; ?></span>
                            </a>

                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Header End -->
    </header>

    <main class="container mt-4">
        <div class="row">
            <div class="col-lg-6">
                <!-- Admin Functions -->
                <div class="admin-functions" style="height: 500px; overflow-y:auto; ">
                    <h2>
                        <img src="image/Admin-icon.png" width="11%" height="11%" alt="">
                        Admin Functions

                    </h2>
                    <!-- View Products -->
                    <h4>View Products</h4>
                    <table class="table ">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Type</th>
                                <th>Image</th>
                                <th>Actions</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($product['id'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td><?php echo htmlspecialchars($product['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td><?php echo htmlspecialchars($product['price'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td><?php echo htmlspecialchars($product['type'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td><img src="<?php echo htmlspecialchars($product['image'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($product['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" width="100"></td>
                                    <td class="action-buttons">
                                        <a href="edit_product.php?id=<?php echo htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-warning btn-sm">Edit</a><br><br>
                                        <a href="delete_product.php?id=<?php echo htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-danger btn-sm">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>


                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-6">
                <!-- Add New Products Form -->
                <div class="form-container" style="height: 500px;">
                    <h2>
                        <img src="image/add-icon.png" width="10%" height="10%" alt="">
                        Add New Product

                    </h2>
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success" role="alert"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
                    <?php elseif (isset($error)): ?>
                        <div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
                    <?php endif; ?>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Price</label>
                            <input tpey="number" class="form-control" id="price" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label for="type" class="form-label">Type</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="tablet">Tablet</option>
                                <option value="oppo">Oppo</option>
                                <option value="vivo">Vivo</option>
                                <option value="Xiaomi">Xiaomi</option>
                                <option value="samsung">Samsung</option>
                                <option value="iphone">iPhone</option>
                                <option value="honor">Honor</option>
                                <option value="realme">Realme</option>
                                <option value="google_pixel">Google Pixel</option>
                                <option value="oneplus">OnePlus</option>
                                <option value="huawei">Huawei</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Product Image</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                        </div>
                        <button type="submit" class="btn btn-primary" name="submit">Add Product</button>
                    </form>
                </div>
            </div>

            <br><br><br><br>
            <div class="container mt-6">
                <div class="col">
                    <br><br>
                    <div class="admin-functions">
                        <div class="row">
                            <center>
                                <div class="col-lg-4">

                                    <h2 class="text-center bg-light text-danger" style=" border-radius: 5px; padding: 4px ;">
                                        <img src="image/icon-order-1.png" width="15%" height="15%" alt="">
                                        Manage Orders
                                    </h2>
                                </div>
                            </center>
                        </div>
                        <h1>Orders List</h1>
                        <div style="height: 500px; overflow-y:auto;">
                            <!-- Manage Orders -->
                            <div class="container mt-12">

                            </div>

                            <table class="table table-striped table-bordered">
                                <thead>

                                    <tr>
                                        <th>Order ID</th>
                                        <th>Name</th>
                                        <th>Product Name</th>
                                        <th>Total Price</th>
                                        <th>Quantity</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($order as $orders): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($orders['id'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo htmlspecialchars($orders['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo htmlspecialchars($orders['product_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo htmlspecialchars($orders['total_price'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo htmlspecialchars($orders['quantity'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo htmlspecialchars($orders['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo htmlspecialchars($orders['address'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td class="action-buttons">
                                                <a href="edit_order.php?id=<?php echo htmlspecialchars($orders['id'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-warning btn-sm">Edit</a><br><br>
                                                <a href="delete_order.php?id=<?php echo htmlspecialchars($orders['id'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-danger btn-sm">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>


                        </div>
                    </div>
                    <br><br>
                    <div class="admin-functions">
                        <!-- User Management -->
                        <div class="container mt-12">
                            <div class="row">
                                <center>
                                    <div class="col-lg-4">

                                        <h2 class="text-center bg-light text-danger" style=" border-radius: 5px; padding: 5px ;">
                                            <img src="image/user_list_icon.png" width="11%" height="12%" alt="">
                                            User Management
                                        </h2>
                                    </div>
                                </center>
                            </div>
                        </div>
                        <h1>Users List</h1>
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>User ID</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Password Hash</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['id'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($user['full_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($user['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($user['phone_number'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($user['password_hash'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td class="action-buttons">
                                            <a href="edit_user.php?id=<?php echo htmlspecialchars($user['id'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-warning btn-sm">Edit</a><br><br>
                                            <a href="delete_user.php?id=<?php echo htmlspecialchars($user['id'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                    </div>
                    <br><br>
                    <div class="admin-functions">
                        <div class="row">
                            <center>
                                <div class="col-lg-4">

                                    <h2 class="text-center bg-light text-danger">
                                        <img src="image/order_items_icon.svg" width="11%" height="12%" alt="">
                                        Manage Order Items
                                    </h2>
                                </div>
                            </center>
                        </div>
                        <h4 class="mb-3">Order Items List</h4>
                        <div style="height: 500px; overflow-y:auto;">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Order ID</th>
                                        <th scope="col">Product ID</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Total Price</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orderItems as $item): ?>
                                        <tr>
                                            <th scope="row"><?php echo htmlspecialchars($item['id'] ?? 'N/A'); ?></th>
                                            <td><?php echo htmlspecialchars($item['order_id'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($item['product_id'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($item['quantity'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($item['price'] ?? 'N/A'); ?></td>
                                            <td>
                                                <!-- Edit Button -->
                                                <a href="edit_order_item.php?id=<?php echo urlencode($item['id']); ?>" class="btn btn-warning btn-sm">Edit</a>

                                                <!-- Delete Button -->
                                                <form action="delete_order_item.php" method="post" style="display:inline;">
                                                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($item['id']); ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                    <!-- Order Items Display End -->
                    <br><br>

                </div>

            </div>
            <br><br>
            <?php
            include('manage_contacts.php');
            ?>
            


    </main>
    <br><br>                                    
    <footer class="bg-light text-center text-lg-start">
        <div class="container p-4">
            <div class="row">
                <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">My Mobile Shop</h5>
                    <p>Your one-stop shop for the latest mobile phones. We offer a wide range of smartphones with the best deals and discounts.</p>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">Quick Links</h5>
                    <ul class="list-unstyled mb-0">
                        <li><a href="index.php" class="text-dark">Home</a></li>
                        <li><a href="products.php" class="text-dark">Products</a></li>
                        <li><a href="cart.php" class="text-dark">Cart</a></li>
                        <li><a href="contact.php" class="text-dark">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">Contact Us</h5>
                    <ul class="list-unstyled mb-0">
                        <li><i class="bi bi-geo-alt"></i> Myaynigone, Yangon</li>
                        <li><i class="bi bi-envelope"></i> mycontact.com101@gmail.com</li>
                        <li><i class="bi bi-phone"></i> +95 9 456 459 778</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="text-center p-3 bg-dark text-white">
            &copy; 2024 Mai Naw Mobile. All rights reserved.
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>