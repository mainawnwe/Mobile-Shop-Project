<?php
// delete_order_item.php
include 'database.php'; // Include your database connection script

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];

    // Delete the order item from the database
    $query = "DELETE FROM order_items WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);

    // Redirect to the admin page after deletion
    header('Location: admin.php');
    exit;
}
?>
