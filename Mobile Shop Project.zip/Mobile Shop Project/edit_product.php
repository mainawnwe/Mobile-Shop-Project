<?php
include('connection.php');

// Fetch product details
if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);
    $stmt = $connection->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        echo "Product not found!";
        exit;
    }
} else {
    echo "Invalid product ID!";
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $price = trim($_POST['price']);
    $type = trim($_POST['type']);
    $product_id = intval($_POST['id']);

    // Basic validation
    if (empty($name) || empty($price) || empty($type)) {
        $error = 'Please fill in all fields.';
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = 'Please enter a valid price.';
    } else {
        // Handle image update if a new image was uploaded
        if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
            $image = $_FILES['image'];
            $imageName = basename($image['name']);
            $imagePath = 'images/' . $imageName;

            if (move_uploaded_file($image['tmp_name'], $imagePath)) {
                $stmt = $connection->prepare("UPDATE products SET name = ?, price = ?, type = ?, image = ? WHERE id = ?");
                $stmt->execute([$name, $price, $type, $imagePath, $product_id]);
            } else {
                $error = 'Failed to upload new image.';
            }
        } else {
            // Update without changing the image
            $stmt = $connection->prepare("UPDATE products SET name = ?, price = ?, type = ? WHERE id = ?");
            $stmt->execute([$name, $price, $type, $product_id]);
        }

        if (!isset($error)) {
            header('Location: admin.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .admin-functions {
            padding: 20px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <header>
        <!-- Header Start -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="image/mainawlogo.png" alt="My Mobile Shop" width="70" height="70" class="d-inline-block align-text-top rounded-circle">
                </a>
                <h3>Mai Naw Mobile</h3>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active btn btn-primary text-white" href="index.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-fill" viewBox="0 0 16 16">
                                    <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293z" />
                                    <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293z" />
                                </svg>
                                Home

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active btn btn-info text-white" href="products.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-fill" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M15.528 2.973a.75.75 0 0 1 .472.696v8.662a.75.75 0 0 1-.472.696l-7.25 2.9a.75.75 0 0 1-.557 0l-7.25-2.9A.75.75 0 0 1 0 12.331V3.669a.75.75 0 0 1 .471-.696L7.443.184l.004-.001.274-.11a.75.75 0 0 1 .558 0l.274.11.004.001zm-1.374.527L8 5.962 1.846 3.5 1 3.839v.4l6.5 2.6v7.922l.5.2.5-.2V6.84l6.5-2.6v-.4l-.846-.339Z" />
                                </svg>
                                Products

                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link active btn btn-success text-white" href="login.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bag-plus-fill" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0M8.5 8a.5.5 0 0 0-1 0v1.5H6a.5.5 0 0 0 0 1h1.5V12a.5.5 0 0 0 1 0v-1.5H10a.5.5 0 0 0 0-1H8.5z" />
                                </svg>
                                Admin
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link active btn btn-secondary text-white" href="contact.php" role="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-rolodex" viewBox="0 0 16 16">
                                    <path d="M8 9.05a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                                    <path d="M1 1a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h.5a.5.5 0 0 0 .5-.5.5.5 0 0 1 1 0 .5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5.5.5 0 0 1 1 0 .5.5 0 0 0 .5.5h.5a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H6.707L6 1.293A1 1 0 0 0 5.293 1zm0 1h4.293L6 2.707A1 1 0 0 0 6.707 3H15v10h-.085a1.5 1.5 0 0 0-2.4-.63C11.885 11.223 10.554 10 8 10c-2.555 0-3.886 1.224-4.514 2.37a1.5 1.5 0 0 0-2.4.63H1z" />
                                </svg>
                                Contact

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active btn btn-warning text-white" role="button" href="cart.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart-check-fill" viewBox="0 0 16 16">
                                    <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0m7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m-1.646-7.646-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L8 8.293l2.646-2.647a.5.5 0 0 1 .708.708" />
                                </svg>
                                Cart <span class="badge bg-danger"><?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : '0'; ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Header End -->
    </header>
    <main class="container mt-4 admin-functions" style="width: 50%;">
        <div class="row">
            <div class="col-lg-6 ">
                <div class="form-container">
                    <h2>Edit Product</h2>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger" role="alert"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
                    <?php endif; ?>
                    <form action="" method="POST" style="width: 200%;" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="mb-3">
                            <label for="name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Price</label>
                            <input type="number" class="form-control" id="price" name="price" value="<?php echo htmlspecialchars($product['price'], ENT_QUOTES, 'UTF-8'); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="type" class="form-label">Type</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="tablet" <?php echo ($product['type'] == 'tablet') ? 'selected' : ''; ?>>Tablet</option>
                                <option value="oppo" <?php echo ($product['type'] == 'oppo') ? 'selected' : ''; ?>>Oppo</option>
                                <option value="vivo" <?php echo ($product['type'] == 'vivo') ? 'selected' : ''; ?>>Vivo</option>
                                <option value="apple" <?php echo ($product['type'] == 'apple') ? 'selected' : ''; ?>>Apple</option>
                                <option value="samsung" <?php echo ($product['type'] == 'samsung') ? 'selected' : ''; ?>>Samsung</option>
                                <option value="xiaomi" <?php echo ($product['type'] == 'xiaomi') ? 'selected' : ''; ?>>xiaomi</option>
                                <option value="oneplus" <?php echo ($product['type'] == 'oneplus') ? 'selected' : ''; ?>>Oneplus</option>
                                <option value="google pixel" <?php echo ($product['type'] == 'google pixel') ? 'selected' : ''; ?>>Google pixel</option>
                                <option value="huawei" <?php echo ($product['type'] == 'huawei') ? 'selected' : ''; ?>>Huawei</option>
                                <option value="honor" <?php echo ($product['type'] == 'honor') ? 'selected' : ''; ?>>Honor</option>
                                <option value="realme" <?php echo ($product['type'] == 'realme') ? 'selected' : ''; ?>>Realme</option>

                                <!-- (other options) -->
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="image" class="form-label">Product Image</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                            <img src="<?php echo htmlspecialchars($product['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="Current Image" width="100" class="mt-2">
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <a href="admin.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <br><br>
    <footer class="bg-light text-center text-lg-start">
        <div class="container p-4">
            <div class="row">
                <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">My Mobile Shop</h5>
                    <p>Your one-stop shop for the latest mobile phones. We offer a wide range of smartphones with the best deals and discounts.</p>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">Quick Links</h5>
                    <ul class="list-unstyled mb-0">
                        <li><a href="index.php" class="text-dark">Home</a></li>
                        <li><a href="products.php" class="text-dark">Products</a></li>
                        <li><a href="cart.php" class="text-dark">Cart</a></li>
                        <li><a href="contact.php" class="text-dark">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">Contact Us</h5>
                    <ul class="list-unstyled mb-0">
                        <li><i class="bi bi-geo-alt"></i> Myaynigone, Yangon</li>
                        <li><i class="bi bi-envelope"></i> mycontact.com101@gmail.com</li>
                        <li><i class="bi bi-phone"></i> +95 9 456 459 778</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="text-center p-3 bg-dark text-white">
            &copy; 2024 Mai Naw Mobile. All rights reserved.
        </div>
    </footer>
</body>

</html>