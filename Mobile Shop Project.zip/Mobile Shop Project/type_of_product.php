<?php
session_start();
include('connection.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Fetch products from the database
$stmt = $connection->query("SELECT * FROM products");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch product types from the database for the dropdown
$typeStmt = $connection->query("SELECT DISTINCT type FROM products");
$types = $typeStmt->fetchAll(PDO::FETCH_COLUMN);

// Handle product type filtering
$selectedType = isset($_GET['type']) ? $_GET['type'] : '';

// Fetch products based on selected type
$query = "SELECT * FROM products";
if ($selectedType) {
    $query .= " WHERE type = :type";
}
$stmt = $connection->prepare($query);
if ($selectedType) {
    $stmt->bindParam(':type', $selectedType);
}
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle "Add to Cart" action
if (isset($_GET['action']) && isset($_GET['id'])) {
    $productId = intval($_GET['id']);

    // Initialize cart if not set
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if ($_GET['action'] == 'add') {
        // Add the product to the cart
        if (isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId]++;
        } else {
            $_SESSION['cart'][$productId] = 1;
        }
    } elseif ($_GET['action'] == 'remove') {
        // Remove the product from the cart
        if (isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId]--;
            if ($_SESSION['cart'][$productId] <= 0) {
                unset($_SESSION['cart'][$productId]);
            }
        }
    }

    // Redirect to prevent reloading the page on refresh
    header("Location: products.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mai Naw Mobile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <header>
        <!-- Header Start -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="images/mainawlogo.png" alt="My Mobile Shop" width="70" height="70" class="d-inline-block align-text-top rounded-circle">
                </a>
                <h3>Mai Naw Mobile</h3>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active btn btn-primary text-white" href="index.php">
                                <!-- Home SVG -->
                                Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-info text-white" href="products.php" role="button">
                                <!-- Products SVG -->
                                Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-success text-white" href="login.php" role="button">
                                <!-- Admin SVG -->
                                Admin
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-info text-white" href="login.php" role="button">
                                <!-- Login SVG -->
                                Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-secondary text-white" href="contact.php" role="button">
                                <!-- Contact SVG -->
                                Contact
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn btn-warning text-white" role="button" href="cart.php">
                                <!-- Cart SVG -->
                                Cart
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Header End -->
    </header>
    <div class="container-fluid">
        <section id="products" class="my-4">
            <form method="get" class="mb-4">
                <div class="row">
                    <div class="col">
                        <select name="type" class="form-select" onchange="this.form.submit()">
                            <option value="">Select Type</option>
                            <?php foreach ($types as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>" <?php echo ($selectedType == $type) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($type); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-12">
                    <?php
                    // Display the products in a table format
                    echo '<table class="table table-striped">';
                    echo '<thead>';
                    echo '<tr>';
                    echo '<th>Image</th>';
                    echo '<th>Name</th>';
                    echo '<th>Price</th>';
                    echo '<th>Quantity</th>';
                    echo '<th>Action</th>';
                    echo '</tr>';
                    echo '</thead>';
                    echo '<tbody>';

                    foreach ($products as $product) {
                        echo '<tr>';
                        echo '<td><img src="images/' . htmlspecialchars($product['image']) . '" alt="' . htmlspecialchars($product['name']) . '" style="width: 100px; height: auto;"></td>';
                        echo '<td>' . htmlspecialchars($product['name']) . '</td>';
                        echo '<td>$' . htmlspecialchars($product['price']) . '</td>';
                        echo '<td>';

                        // Check if product is in cart and display quantity controls
                        if (isset($_SESSION['cart'][$product['id']])) {
                            $quantity = $_SESSION['cart'][$product['id']];
                            echo '<div class="btn-group" role="group">';
                            echo '<a href="index.php?action=remove&id=' . $product['id'] . '" class="btn btn-danger">-</a>';
                            echo '<span class="btn btn-light">' . $quantity . '</span>';
                            echo '<a href="index.php?action=add&id=' . $product['id'] . '" class="btn btn-success">+</a>';
                            echo '</div>';
                        } else {
                            echo '0';
                        }

                        echo '</td>';
                        echo '<td>';
                        echo '<a href="index.php?action=add&id=' . $product['id'] . '" class="btn btn-warning">Add to Cart</a>';
                        echo '</td>';
                        echo '</tr>';
                    }

                    echo '</tbody>';
                    echo '</table>';
                    ?>


                </div>
            </div>
        </section>
    </div>
    <footer class="bg-light text-center text-lg-start">
        <div class="container p-4">
            <div class="row">
                <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">My Mobile Shop</h5>
                    <p>Your one-stop shop for the latest mobile phones. We offer a wide range of smartphones with the best deals and discounts.</p>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">Quick Links</h5>
                    <ul class="list-unstyled mb-0">
                        <li><a href="index.php" class="text-dark">Home</a></li>
                        <li><a href="products.php" class="text-dark">Products</a></li>
                        <li><a href="cart.php" class="text-dark">Cart</a></li>
                        <li><a href="contact.php" class="text-dark">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase" style="color:#d14617;">Contact Us</h5>
                    <ul class="list-unstyled mb-0">
                        <li><i class="bi bi-house-door"></i> Address: 123 Mobile St, City, Country</li>
                        <li><i class="bi bi-envelope"></i> Email: info@mymobileshop.com</li>
                        <li><i class="bi bi-phone"></i> Phone: +123 456 7890</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="text-center p-3" style="background-color: #f1f1f1;">
            &copy; 2024 Mai Naw Mobile. All rights reserved.
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9l5DWz6UUNeA4mE6wT0yG2rbUjzXwN1fA5V9CCv3DOPfI5pN4KD" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-pfYCBFvZlU1N/fau0LUnL1Bo8mrxCBoJ8g6FPw7j7N8QmG1pK4w6AiZ9aFmoT/1Je" crossorigin="anonymous"></script>
</body>

</html>